#define BUFLEN 2047
